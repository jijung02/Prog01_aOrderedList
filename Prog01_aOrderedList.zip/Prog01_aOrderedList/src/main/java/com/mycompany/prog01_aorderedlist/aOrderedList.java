/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog01_aorderedlist;

/**
 *
 * @author jwjun
 */

import java.util.Arrays;

class aOrderedList {
    final int SIZEINCREMENTS = 20; 
	private Comparable[] oList;
	private int listSize;
	private int numObjects;
	private int curr;

	public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Car[SIZEINCREMENTS];
    }
        
        public void add(Comparable newObject) {
        if (numObjects == listSize) {
            // resize if the array is full
            listSize += SIZEINCREMENTS;
            oList = Arrays.copyOf(oList, listSize);
        }
        
        int i = numObjects - 1;
        while (i >= 0 && oList[i].compareTo(newObject) > 0) {
            oList[i + 1] = oList[i];
            i--;
        }
        oList[i + 1] = newObject;
        numObjects++;
    }
	
	public int size() {
		return numObjects;
	}
	
	public Comparable get(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index is out of bounds");
		}
		return oList[index];
	}
	
	public boolean isEmpty() {
		return numObjects == 0;
	}
	
	public void reset() {
		curr = 0;
	}

	public Comparable next() {
		Comparable nextElement = oList[curr];
		curr++;
		return nextElement;
	}
	
	public boolean hasNext() {
		return curr < numObjects;
	}
	
	public void remove(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index is out of bounds");
		}
		
		for (int i = index; i < numObjects - 1; i++) {
			oList[i] = oList[i + 1];
		}
		oList[numObjects - 1] = null;
		numObjects--;
	}
	
	public void delete(String make, int year) {
		for (int i = 0; i < numObjects; i++) {
			Car car = (Car) oList[i];
			if (car.getMake().equals(make) && car.getYear() == year) {
				remove(i);
				break;
			}
		}
	}
	
	public String toString() {
	    String result = "[";
	    for (int i = 0; i < numObjects; i++) {
	        result += oList[i].toString();
	        if (i < numObjects - 1) {
	            result += ", ";
	        }
	    }
	    result += "]";
	    return result;
	}
}
