/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog01_aorderedlist;

/**
 *
 * @author jwjun
 */

import java.io.*;
import java.util.Scanner;

public class Prog01_aOrderedList {

    public static void main(String[] args) {
        Prog01_aOrderedList program = new Prog01_aOrderedList();
        aOrderedList orderedList = new aOrderedList();
		
	try {
            Scanner inputScanner = program.GetInputFile("Enter input filename: ");
            
            while (inputScanner.hasNextLine()) {
            	String line = inputScanner.nextLine();
            	String[] parts = line.split(",");
            	if (parts.length == 4 && parts[0].equals("A")) {
            		String Make = parts[1];
            		int Year = Integer.parseInt(parts[2]);
            		int Price = Integer.parseInt(parts[3]);
            		Car car = new Car(Make, Year, Price);
            		orderedList.add(car);
            	}
            else if (parts.length == 3 && parts[0].equals("D")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    orderedList.delete(make, year);
            	}
            }
            inputScanner.close();
        } 
        
        catch (FileNotFoundException e){
            System.out.println("User cancelled program.");
        }
		
        try {
            PrintWriter outputWriter = program.getOutputFile("Enter output filename: ");
            outputWriter.printf("%-10s %10s\n\n", "Number of cars:", orderedList.size());
            for (int i = 0; i < orderedList.size(); i++) {
            	Car car = (Car) orderedList.get(i);
            	outputWriter.printf("%-10s %10s\n", "Make:", car.getMake());
            	outputWriter.printf("%-10s %10s\n", "Year:", car.getYear());
            	outputWriter.printf("%-10s %10s\n", "Price:", "$" + String.format("%,d", car.getPrice()));
            	if (i < orderedList.size() - 1) {
            		outputWriter.println();
            	}
            }
            outputWriter.close();
            System.out.println("Successfully created file.");
	}
        
            catch (FileNotFoundException e) {
                System.out.println("User cancelled program.");
            }
	}
	
	public Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		String filename;
		Scanner fileScanner = null;
		
		while (fileScanner == null) {
                    System.out.print(UserPrompt);
                    filename = in.nextLine();
                    try {
			fileScanner = new Scanner(new File(filename));
                    }
                    catch (FileNotFoundException e) {
				System.out.println("File specified <" + filename + "> does not exist.");
                System.out.print("Would you like to continue? <Y/N> ");
                String response = in.nextLine();
                if (!response.equalsIgnoreCase("Y")) {      
                            throw new FileNotFoundException();
                        }
                    }
		}
		return fileScanner;
	}
	
	public PrintWriter getOutputFile(String UserPrompt) throws FileNotFoundException {
		Scanner in = new Scanner(System.in);
		PrintWriter writer = null;
		
		while (writer == null) {
                    try {
			System.out.print(UserPrompt);
                        String filename = in.nextLine();
                        writer = new PrintWriter(new File(filename));
                        }  
                    catch (FileNotFoundException e){
			System.out.println("File cannot be created.");
                        System.out.print("Would you like to continue? <Y/N> ");
                        String response = in.nextLine();
                        if (!response.equalsIgnoreCase("Y")) {
                            throw new FileNotFoundException();
                    }
		}
            }
		in.close();
		return writer;
	}
}
