/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog01_aorderedlist;

/**
 *
 * @author jwjun
 */
public class Car implements Comparable<Car>{
        
    private String make;
    private int year;
    private int price;
        
    public Car (String Make, int Year, int Price){
        make = Make;
        year = Year;
        price = Price;
        }
        
    public String getMake(){
        return make;
    }
        
    public int getYear(){
        return year; 
    }
        
    public int getPrice(){
        return price;
    }
        
    @Override
    public int compareTo(Car other){
        if (this.make.compareTo(other.make)!=0){
            return this.make.compareTo(other.make); 
        }
        else{
            return Integer.compare(this.year,other.year);
        }
    }
        
    @Override
    public String toString(){
        return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
    }
}

